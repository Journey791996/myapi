<!DOCTYPE html>
<html>
<head>
	<title>Header</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	
	<script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function () {

			getStudentList();

			$('#edit_form').hide();
			$('#login_form').show();
			
			$('#tbody').on('click','#edit',function () {

			var id = $(this).data('id');
			alert(id);

			$.get('studentlist.json',function(response){
				if(response){
					var studentObjArray = JSON.parse(response);
					

					var name = studentObjArray[id].name;
					var email = studentObjArray[id].email;
					var address = studentObjArray[id].address;
					var profile = studentObjArray[id].profile;
					var gender = studentObjArray[id].gender;

					$('#edit_name').val(name);
					$('#edit_email').val(email);
					$('#edit_address').val(address);
					$('#showOldPhoto').attr('src',profile);
					$('#edit_oldprofile').val(profile);
					$('#edit_id').val(id);

					if(gender =='male'){
						$("input[value='male']").attr('checked',true);
					}
					else
					{
						$("input[value='female']").attr('checked',true);
					}
				}
			})

			$('#edit_form').show();
			$('#login_form').hide();
			});
			function getStudentList(){
			$.get('studentlist.json',function(response){
				if(response){
					 var studentObjArray = JSON.parse(response);
					//var studentObjArray = response;
					console.log(studentObjArray);

					var html ='';
					var j=1;
					$.each(studentObjArray, function(i,v){
						html += `<tr>
									<td>${j++}</td>
									<td>${v.name}</td>
									<td>${v.gender}</td>
									<td>${v.email}</td>
									<td>
									<button class="btn btn-warning btnedit" id="edit" data-id="${i}">Edit</button>
									<button class="btn btn-danger btndelete" id="delete" data-id="${i}">Delete</button>
									</td>
								</tr>`
					});
					$('#tbody').html(html);

				}
			})	
			}

			$('#tbody').on('click','#delete',function(){
				var id = $(this).data('id');
				var ans = confirm('Are you sure want to delete?');

				if(ans){
					$.post(
						'deletestudent.php',{id:id},function(data){
							getStudentList();
						})
				}
			});
		})
	</script>
</head>
<body>
