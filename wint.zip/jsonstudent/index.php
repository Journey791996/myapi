<?php 
require('header.php');
?>
<!-- login form -->
<div class="container my-5" id="login_form">
	<h1 class="text-center mb-4">Add New Student</h1>
	<form action="addstudent.php" method="POST" enctype="multipart/form-data">
		<div class="form-group row">
			<label for="profile" class="col-sm-2 col-form-label">Profile</label>
			<div class="col-sm-10">
				<input type="file" name="profile" id="profile" class="form-control-file">
			</div>
		</div>
		<div class="form-group row">
			<label for="name" class="col-sm-2 col-form-label">Name</label>
			<div class="col-sm-10">
				<input type="text" name="name" id="name" class="form-control">
			</div>
		</div>
		<div class="form-group row">
			<label for="email" class="col-sm-2 col-form-label">Email</label>
			<div class="col-sm-10">
				<input type="Email" name="email" id="email" class="form-control">
			</div>
		</div>
		<div class="form-group row">
			<label for="gender" class="col-sm-2 col-form-label">Gender</label>
			<div class="col-sm-10">
				<div class="form-check form-check-inline">
					<input class="form-check-input" type="radio" name="gender" id="male" value="Male">
					<label class="form-check-label" for="male">Male</label>
				</div>
				<div class="form-check form-check-inline">
					<input class="form-check-input" type="radio" name="gender" id="female" value="Female">
					<label class="form-check-label" for="female" >Female</label>
				</div>
			</div>
		</div>
		<div class="form-group row">
			<label for="address" class="col-sm-2 col-form-label">Address</label>
			<div class="col-sm-10">
				<textarea id="address" class="form-control" name="address"></textarea>
			</div>
		</div>
		<input type="submit" name="button" value="SAVE" class="btn btn-primary">
	</form>
</div>
<!-- edit form -->
<div class="container my-5" id="edit_form">
	<h1 class="text-center mb-4">Edit Existing Student</h1>
	<form action="updatestudent.php" method="POST" enctype="multipart/form-data" >
		<input type="text" name="edit_id" id="edit_id">
		<input type="text" name="edit_oldprofile" id="edit_oldprofile">

		<div class="form-group row">
			<label for="profile" class="col-sm-2 col-form-label">Profile</label>
			<div class="col-sm-10">
				<ul class="nav nav-tabs" id="myTab" role="tablist">
				  <li class="nav-item">
				    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Home</a>
				  </li>
				  <li class="nav-item">
				    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile1" role="tab" aria-controls="profile" aria-selected="false">Profile</a>
				  </li>
				</ul>
				<div class="tab-content" id="myTabContent">
					  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
					  	<img src="" id="showOldPhoto" class="img-fluid" width="100" height="100">
					  </div>

					  <div class="tab-pane fade" id="profile1" role="tabpanel" aria-labelledby="profile-tab"><input type="file" id="profile" name="edit_newprofile">new profile</div>
				</div>
			</div>
		</div>
		<div class="form-group row">
			<label for="edit_name" class="col-sm-2 col-form-label">Name</label>
			<div class="col-sm-10">
				<input type="text" name="edit_name" id="edit_name" class="form-control">
			</div>
		</div>
		<div class="form-group row">
			<label for="edit_email" class="col-sm-2 col-form-label">Email</label>
			<div class="col-sm-10">
				<input type="Email" name="edit_email" id="edit_email" class="form-control">
			</div>
		</div>
		<div class="form-group row">
			<label for="edit_gender" class="col-sm-2 col-form-label">Gender</label>
			<div class="col-sm-10">
				<div class="form-check form-check-inline">
					<input class="form-check-input" type="radio" name="edit_gender" id="male" value="male">
					<label class="form-check-label" for="male">Male</label>
				</div>
				<div class="form-check form-check-inline">
					<input class="form-check-input" type="radio" name="edit_gender" id="female" value="female">
					<label class="form-check-label" for="female">Female</label>
				</div>
			</div>
		</div>
		<div class="form-group row">
			<label for="edit_address" class="col-sm-2 col-form-label">Address</label>
			<div class="col-sm-10">
				<textarea id="edit_address" class="form-control" name="edit_address"></textarea>
			</div>
		</div>
		<input type="submit" name="button" value="Update" class="btn btn-primary">
	</form>
</div>
<!-- table -->
<div class="container my-4">
	<div class="table-responsive">
				<table class="table table-striped text-center">
					<thead class="bg-dark">
						<tr class="text-light">
							<th>#</th>
							<th>Name</th>
							<th>Gender</th>
							<th>Email</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody id="tbody">
						<!-- <tr>
							<td>1</td>
							<td>Wint Mon Mon Ei</td>
							<td>Female</td>
							<td>1wintmon1@gmail.com</td>
							<td><button class="btn btn-success">Detail</button><button id="edit" class="btn btn-primary mx-3">Edit</button><button class="btn btn-danger">Delete</button></td>
						</tr> -->
					</tbody>
				</div>
			</table>
</div>
<!-- test -->
<?php 
require('footer.php'); 
?>